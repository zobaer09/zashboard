# File adapters (stubs) using Arrow and DuckDB

zash_read_parquet <- function(path) {
  # arrow::open_dataset(path)
  invisible(NULL)
}
