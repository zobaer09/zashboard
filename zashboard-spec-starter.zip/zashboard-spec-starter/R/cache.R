# Cache helpers (stubs)
zash_cache_status <- function() list(ok = TRUE)
