**Summary**

**Checklist**
- [ ] Tests added or updated
- [ ] Docs updated
- [ ] R CMD check passes
