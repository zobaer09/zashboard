# Code of Conduct

Be respectful. Assume good intent. No harassment or discrimination. Report issues to maintainers.
