# Security Policy

Do not place credentials in client code or public repos. Use environment variables or secrets.
Report vulnerabilities by opening a private security advisory with repro steps.
