// Zashboard minimal JS (placeholder)
// Progressive enhancement: mark the page as JS-enabled.
document.documentElement.classList.add('js-enabled');
console.info('zashboard.js loaded');
