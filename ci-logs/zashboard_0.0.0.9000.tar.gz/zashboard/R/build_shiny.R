#' Build a Shiny app
#'
#' @param spec Path to a YAML spec (e.g., 'inst/templates/zashboard.yml') or a list-like spec already parsed. Defaults to NULL.
#' @param ...  Additional options passed to the Shiny builder.
#' @export
build_shiny <- function(spec = NULL, ...) {
  # TODO: implement
  invisible(TRUE)
}
