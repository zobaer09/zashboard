#' Build static HTML output
#'
#' @param spec Path to a YAML spec (e.g., 'inst/templates/zashboard.yml') or a list-like spec already parsed. Defaults to NULL.
#' @param ...  Additional options passed to the static builder.
#' @export
build_static <- function(spec = NULL, ...) {
  # TODO: implement
  invisible(TRUE)
}

