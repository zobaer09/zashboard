# Semantic layer stubs

zash_define_relationships <- function(...) invisible(NULL)
zash_define_measures <- function(...) invisible(NULL)
