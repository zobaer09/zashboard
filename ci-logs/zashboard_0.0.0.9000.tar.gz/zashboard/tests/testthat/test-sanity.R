test_that("package loads", {
  expect_true(requireNamespace("zashboard", quietly = TRUE))
})
