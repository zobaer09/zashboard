# Validator stubs
zash_validate_spec <- function(spec) {
  list(ok = TRUE, messages = character())
}
