# DB adapters (stubs)
# Use DBI/odbc and dbplyr

zash_connect_mssql <- function(dsn = NULL, ...) {
  # odbc::dbConnect(odbc::odbc(), dsn = dsn, ...)
  invisible(NULL)
}
