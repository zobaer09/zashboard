(function(){ /* zashboard minimal */ })();
