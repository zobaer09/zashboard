## ----include=FALSE------------------------------------------------------------
# Show code, but don't run heavy chunks during vignette builds.
# If you really want to execute the examples locally:
# Sys.setenv(ZASH_VIG_RUN = "1"); devtools::build_vignettes()
run_examples <- identical(Sys.getenv("ZASH_VIG_RUN", "0"), "1")
knitr::opts_chunk$set(collapse = TRUE, comment = "#>", eval = run_examples)

