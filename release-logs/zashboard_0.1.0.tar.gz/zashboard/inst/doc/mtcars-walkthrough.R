## ----include=FALSE------------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(zashboard)
spec <- system.file("examples/mtcars/mtcars.yml", package = "zashboard", mustWork = TRUE)

## -----------------------------------------------------------------------------
static_dir <- zashboard::build_static(spec, overwrite = TRUE)
static_dir

## -----------------------------------------------------------------------------
sl_dir <- zashboard::build_shinylive(spec, overwrite = TRUE)
sl_dir

## ----eval=FALSE---------------------------------------------------------------
# # app <- zashboard::build_shiny(spec)
# # shiny::runApp(app)

## -----------------------------------------------------------------------------
qdir <- file.path(tempdir(), "zash-mtcars-quarto")
zashboard::build_quarto(spec, out_dir = qdir, overwrite = TRUE)
qdir

