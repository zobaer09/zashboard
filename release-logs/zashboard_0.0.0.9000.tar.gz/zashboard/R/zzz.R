#' Zashboard
#'
#' Build dashboards from a single spec to static HTML, Shiny, or Shinylive.
#' @keywords internal
"_PACKAGE"
